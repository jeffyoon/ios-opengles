#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 Ball_Sphere_ball_ambient;
const GLKVector4 Ball_Sphere_ball_diffuse;
const GLKVector4 Ball_Sphere_ball_specular;
const float Ball_Sphere_ball_shininess;
const RWTVertex Ball_Sphere_ball_Vertices[420];

