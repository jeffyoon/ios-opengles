#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 Border_Cube_Border_ambient;
const GLKVector4 Border_Cube_Border_diffuse;
const GLKVector4 Border_Cube_Border_specular;
const float Border_Cube_Border_shininess;
const RWTVertex Border_Cube_Border_Vertices[132];

