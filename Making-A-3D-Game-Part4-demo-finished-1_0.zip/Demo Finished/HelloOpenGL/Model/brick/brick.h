#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 Cube_brick_ambient;
const GLKVector4 Cube_brick_diffuse;
const GLKVector4 Cube_brick_specular;
const float Cube_brick_shininess;
const RWTVertex Cube_brick_Vertices[36];

