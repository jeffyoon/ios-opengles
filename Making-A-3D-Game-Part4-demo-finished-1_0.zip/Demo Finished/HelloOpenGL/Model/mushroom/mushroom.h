#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 Mushroom_Cylinder_mushroom_ambient;
const GLKVector4 Mushroom_Cylinder_mushroom_diffuse;
const GLKVector4 Mushroom_Cylinder_mushroom_specular;
const float Mushroom_Cylinder_mushroom_shininess;
const RWTVertex Mushroom_Cylinder_mushroom_Vertices[420];

