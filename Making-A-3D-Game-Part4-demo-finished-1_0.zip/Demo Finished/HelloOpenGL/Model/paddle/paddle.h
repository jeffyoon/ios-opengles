#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 Paddle_Cube_paddle_ambient;
const GLKVector4 Paddle_Cube_paddle_diffuse;
const GLKVector4 Paddle_Cube_paddle_specular;
const float Paddle_Cube_paddle_shininess;
const RWTVertex Paddle_Cube_paddle_Vertices[36];

