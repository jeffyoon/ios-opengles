#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 youlose_Mesh_001_youlose_ambient;
const GLKVector4 youlose_Mesh_001_youlose_diffuse;
const GLKVector4 youlose_Mesh_001_youlose_specular;
const float youlose_Mesh_001_youlose_shininess;
const RWTVertex youlose_Mesh_001_youlose_Vertices[12864];

