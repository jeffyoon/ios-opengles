#import <GLKit/GLKit.h>

#import "RWTVertex.h"

const GLKVector4 Text_Mesh_youwin_ambient;
const GLKVector4 Text_Mesh_youwin_diffuse;
const GLKVector4 Text_Mesh_youwin_specular;
const float Text_Mesh_youwin_shininess;
const RWTVertex Text_Mesh_youwin_Vertices[5184];

