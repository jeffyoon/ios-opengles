//
//  RWTCube.h
//  HelloOpenGL
//
//  Created by Main Account on 3/21/14.
//  Copyright (c) 2014 Razeware LLC. All rights reserved.
//

#import "RWTModel.h"

@interface RWTCube : RWTModel

- (instancetype)initWithShader:(RWTBaseEffect *)shader;

@end
