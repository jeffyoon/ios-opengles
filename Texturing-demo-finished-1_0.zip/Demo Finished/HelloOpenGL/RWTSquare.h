//
//  RWTSquare.h
//  HelloOpenGL
//
//  Created by Main Account on 3/18/14.
//  Copyright (c) 2014 Razeware LLC. All rights reserved.
//

#import "RWTModel.h"

@interface RWTSquare : RWTModel

- (instancetype)initWithShader:(RWTBaseEffect *)shader;

@end
