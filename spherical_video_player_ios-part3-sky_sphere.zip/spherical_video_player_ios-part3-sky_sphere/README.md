# Spherical Video Player
Project showing how to build a simple player for video 360°.
